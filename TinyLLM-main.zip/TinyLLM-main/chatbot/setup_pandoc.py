from pypandoc.pandoc_download import download_pandoc
download_pandoc()

