#!/bin/bash

# Create Container
docker build -t llmserver .

